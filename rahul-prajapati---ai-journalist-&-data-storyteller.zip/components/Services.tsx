import React from 'react';
import { SERVICES } from '../constants';
import * as Icons from 'lucide-react';
import RevealOnScroll from './RevealOnScroll';

const Services: React.FC = () => {
  return (
    <div className="py-12 bg-gray-900" id="services">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RevealOnScroll>
          <div className="lg:text-center">
            <h2 className="text-base text-brand-lightBlue font-semibold tracking-wide uppercase">Offers</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-white sm:text-4xl">
              Your Complete Service Roadmap
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-400 lg:mx-auto">
              From initial idea to delivery. Scalable packages designed for high impact.
            </p>
          </div>

          <div className="mt-10">
            <div className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 lg:grid-cols-3 md:gap-x-8 md:gap-y-10">
              {SERVICES.map((service) => {
                // Dynamically resolve icon
                const IconComponent = (Icons as any)[service.icon] || Icons.HelpCircle;

                return (
                  <div key={service.id} className="flex flex-col bg-gray-800 rounded-lg shadow-lg overflow-hidden border border-gray-700 hover:border-brand-yellow transition-colors duration-300">
                    <div className="p-6 flex-1">
                      <div className="flex items-center justify-between mb-4">
                          <div className="flex-shrink-0">
                              <span className="h-10 w-10 rounded-md bg-brand-blue flex items-center justify-center text-brand-yellow">
                                  <IconComponent className="h-6 w-6" />
                              </span>
                          </div>
                      </div>
                      
                      <h3 className="text-xl font-medium text-white">{service.title}</h3>
                      <p className="mt-4 text-base text-gray-400">
                        {service.description}
                      </p>

                      <div className="mt-6 border-t border-gray-700 pt-4">
                          <h4 className="text-sm font-bold text-gray-300 uppercase tracking-wider mb-3">Packages</h4>
                          <ul className="space-y-2">
                              {service.packages.map((pkg, idx) => (
                                  <li key={idx} className="flex justify-between items-start text-sm">
                                      <span className="text-gray-400">{pkg.name}</span>
                                      <span className="font-semibold text-brand-lightBlue whitespace-nowrap ml-2">{pkg.price}</span>
                                  </li>
                              ))}
                          </ul>
                      </div>
                    </div>
                    <div className="bg-brand-blue px-6 py-3">
                       <a href={`#contact`} className="text-sm font-medium text-brand-yellow hover:text-white transition-colors flex items-center justify-center">
                          Book this Service <Icons.ArrowRight className="ml-2 w-4 h-4"/>
                       </a>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  );
};

export default Services;
