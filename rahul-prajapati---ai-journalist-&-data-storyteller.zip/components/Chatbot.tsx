import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Bot, User } from 'lucide-react';
import { sendMessageToGemini } from '../services/gemini';
import { ChatMessage } from '../types';

const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: "Hi! I'm Rahul's AI assistant. Ask me anything about his services, pricing, or experience!" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: ChatMessage = { role: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      // Send entire history for context
      const responseText = await sendMessageToGemini(messages.concat(userMessage), input);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: "Sorry, I encountered an error. Please try again." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') handleSend();
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end font-sans">
      {/* Chat Window */}
      {isOpen && (
        <div className="bg-gray-800 rounded-lg shadow-2xl w-80 sm:w-96 mb-4 border border-gray-700 overflow-hidden flex flex-col max-h-[500px] animate-fade-in-up">
          {/* Header */}
          <div className="bg-brand-blue p-4 flex justify-between items-center text-white">
            <div className="flex items-center">
                <Bot className="w-5 h-5 mr-2" />
                <span className="font-semibold">Rahul's AI Assistant</span>
            </div>
            <button onClick={() => setIsOpen(false)} className="hover:text-brand-yellow transition-colors">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 p-4 overflow-y-auto scrollbar-thin bg-gray-900 h-80">
            {messages.map((msg, idx) => (
              <div key={idx} className={`flex mb-4 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                {msg.role === 'model' && (
                    <div className="w-8 h-8 rounded-full bg-brand-blue flex items-center justify-center text-white mr-2 flex-shrink-0">
                        <Bot className="w-4 h-4" />
                    </div>
                )}
                <div className={`p-3 rounded-lg max-w-[80%] text-sm ${
                  msg.role === 'user' 
                    ? 'bg-brand-blue text-white rounded-br-none' 
                    : 'bg-gray-700 border border-gray-600 text-gray-100 rounded-bl-none shadow-sm'
                }`}>
                  {msg.text}
                </div>
                 {msg.role === 'user' && (
                    <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center text-gray-300 ml-2 flex-shrink-0">
                        <User className="w-4 h-4" />
                    </div>
                )}
              </div>
            ))}
            {isLoading && (
               <div className="flex mb-4 justify-start">
                  <div className="w-8 h-8 rounded-full bg-brand-blue flex items-center justify-center text-white mr-2 flex-shrink-0">
                        <Bot className="w-4 h-4" />
                    </div>
                  <div className="bg-gray-700 border border-gray-600 p-3 rounded-lg rounded-bl-none shadow-sm flex items-center">
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce mr-1"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce mr-1 delay-75"></div>
                    <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-150"></div>
                  </div>
               </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <div className="p-3 border-t border-gray-700 bg-gray-800 flex items-center">
            <input
              type="text"
              className="flex-1 border border-gray-600 bg-gray-700 rounded-full px-4 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-brand-blue focus:border-transparent placeholder-gray-400"
              placeholder="Ask about services..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
            />
            <button 
                onClick={handleSend}
                disabled={isLoading}
                className="ml-2 bg-brand-blue text-white p-2 rounded-full hover:bg-blue-700 transition-colors disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-brand-yellow text-brand-blue p-4 rounded-full shadow-lg hover:bg-yellow-400 transition-all hover:scale-105 border-2 border-brand-blue"
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </button>
    </div>
  );
};

export default Chatbot;