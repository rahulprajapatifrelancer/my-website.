import React from 'react';
import { ROADMAP } from '../constants';
import { CheckCircle2 } from 'lucide-react';
import RevealOnScroll from './RevealOnScroll';

const Roadmap: React.FC = () => {
  return (
    <div className="py-16 bg-gray-800" id="roadmap">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RevealOnScroll>
          <div className="text-center mb-12">
            <h2 className="text-base text-brand-yellow font-semibold tracking-wide uppercase">The Process</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-white sm:text-4xl">
              Start to Finish: How We Work
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-300 mx-auto">
              A structured, transparent roadmap from the first DM to final delivery.
            </p>
          </div>

          <div className="relative">
            {/* Vertical Line for Desktop */}
            <div className="hidden md:block absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gray-600" />

            <div className="space-y-12">
              {ROADMAP.map((step, index) => {
                const isEven = index % 2 === 0;
                return (
                  <div key={index} className={`relative flex items-center ${isEven ? 'md:flex-row' : 'md:flex-row-reverse'} flex-col`}>
                    
                    {/* Timeline Dot */}
                    <div className="hidden md:flex absolute left-1/2 transform -translate-x-1/2 items-center justify-center w-8 h-8 rounded-full bg-brand-yellow ring-4 ring-gray-700 z-10">
                      <span className="text-brand-blue font-bold text-xs">{index + 1}</span>
                    </div>

                    {/* Content Box */}
                    <div className={`w-full md:w-1/2 ${isEven ? 'md:pr-12' : 'md:pl-12'} mb-8 md:mb-0`}>
                       <div className="bg-gray-700 rounded-lg p-6 shadow-xl border border-gray-600">
                          <div className="flex justify-between items-center mb-2">
                               <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-900 text-blue-100">
                                  {step.phase}
                               </span>
                               <span className="text-sm text-gray-400 font-semibold">{step.duration}</span>
                          </div>
                          <h3 className="text-xl font-bold text-white mb-3">{step.title}</h3>
                          <ul className="space-y-2">
                              {step.items.map((item, idx) => (
                                  <li key={idx} className="flex items-start">
                                      <CheckCircle2 className="w-4 h-4 text-green-400 mt-1 mr-2 flex-shrink-0" />
                                      <span className="text-sm text-gray-300">{item}</span>
                                  </li>
                              ))}
                          </ul>
                       </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  );
};

export default Roadmap;