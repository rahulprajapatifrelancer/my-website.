import React from 'react';
import { Camera, BarChart, PenTool } from 'lucide-react';
import { PROFILE, EXPERIENCE } from '../constants';
import RevealOnScroll from './RevealOnScroll';

const About: React.FC = () => {
  return (
    <div className="py-16 bg-gray-800 overflow-hidden" id="about">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RevealOnScroll>
          <div className="text-center">
            <h2 className="text-base font-semibold text-brand-yellow tracking-wide uppercase">Who I Am</h2>
            <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-white sm:text-4xl">
              Unconventional Paths are My Edge
            </p>
            <p className="mt-4 max-w-2xl text-xl text-gray-300 mx-auto">
              I don't fit into boxes. From managing reality TV cameras to mining data analytics, I bring a unique perspective to AI content.
            </p>
          </div>

          <div className="mt-16">
            <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-3 md:gap-x-8 md:gap-y-10">
              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-brand-blue text-white">
                    <Camera className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-white">Visual Storytelling</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-400">
                  Former Camera Assistant for Bigg Boss. I know how to frame a shot—and a story—for millions of viewers.
                </dd>
              </div>

              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-brand-blue text-white">
                    <BarChart className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-white">Data Analytics</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-400">
                  Prevented ₹15+ lakhs monthly losses in mining operations through real-time KPI dashboards and predictive analytics.
                </dd>
              </div>

              <div className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-brand-blue text-white">
                    <PenTool className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-white">AI Journalism</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-400">
                  Bridging the gap between raw data and human stories using Generative AI and Agents.
                </dd>
              </div>
            </dl>
          </div>
          
          <div className="mt-16 bg-gray-700 shadow overflow-hidden sm:rounded-lg">
            <div className="px-4 py-5 sm:px-6 border-b border-gray-600">
               <h3 className="text-lg leading-6 font-medium text-brand-lightBlue">
                 Experience
               </h3>
            </div>
            <ul className="divide-y divide-gray-600">
              {EXPERIENCE.map((exp, idx) => (
                <li key={idx} className="px-4 py-5 sm:px-6 hover:bg-gray-600 transition">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-brand-lightBlue truncate">{exp.role}</p>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-900 text-yellow-200">
                        {exp.duration}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 sm:flex sm:justify-between">
                    <div className="sm:flex">
                      <p className="flex items-center text-sm text-gray-400">
                        {exp.company}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2 text-sm text-gray-300 space-y-1">
                    {exp.description.map((d, i) => (
                      <p key={i}>• {d}</p>
                    ))}
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  );
};

export default About;