import React from 'react';
import { Mail, Linkedin, Phone } from 'lucide-react';
import { PROFILE } from '../constants';
import RevealOnScroll from './RevealOnScroll';

const Contact: React.FC = () => {
  return (
    <div className="bg-gray-900 py-16" id="contact">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <RevealOnScroll>
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-extrabold text-white">Ready to transform your content?</h2>
            <p className="mt-4 text-lg text-gray-400">
              Let's discuss how we can use AI and storytelling to grow your brand.
            </p>
          </div>
          <div className="mt-12 flex flex-col md:flex-row justify-center items-center space-y-4 md:space-y-0 md:space-x-8">
              <a 
                  href={`mailto:${PROFILE.contact.email}`}
                  className="flex items-center px-6 py-4 bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-700 w-full md:w-auto"
              >
                  <div className="bg-brand-blue p-3 rounded-full text-white mr-4">
                      <Mail className="w-6 h-6" />
                  </div>
                  <div>
                      <p className="text-sm text-gray-400">Email Me</p>
                      <p className="font-semibold text-white">{PROFILE.contact.email}</p>
                  </div>
              </a>

              <a 
                  href={`https://${PROFILE.contact.linkedin}`}
                  target="_blank"
                  rel="noreferrer"
                  className="flex items-center px-6 py-4 bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-700 w-full md:w-auto"
              >
                  <div className="bg-brand-blue p-3 rounded-full text-white mr-4">
                      <Linkedin className="w-6 h-6" />
                  </div>
                  <div>
                      <p className="text-sm text-gray-400">LinkedIn</p>
                      <p className="font-semibold text-white">Connect & DM</p>
                  </div>
              </a>
              
               <div className="flex items-center px-6 py-4 bg-gray-800 rounded-lg shadow-md hover:shadow-lg transition-shadow border border-gray-700 w-full md:w-auto">
                  <div className="bg-brand-blue p-3 rounded-full text-white mr-4">
                      <Phone className="w-6 h-6" />
                  </div>
                  <div>
                      <p className="text-sm text-gray-400">Call</p>
                      <p className="font-semibold text-white">{PROFILE.contact.phone}</p>
                  </div>
              </div>
          </div>
        </RevealOnScroll>
      </div>
    </div>
  );
};

export default Contact;
