import React from 'react';
import Hero from './components/Hero';
import About from './components/About';
import Services from './components/Services';
import Roadmap from './components/Roadmap';
import Contact from './components/Contact';
import Chatbot from './components/Chatbot';

const App: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-900">
      {/* Navigation */}
      <nav className="bg-gray-900 shadow-sm border-b border-gray-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
               <span className="text-xl font-bold text-white">Rahul<span className="text-brand-yellow">Prajapati</span></span>
            </div>
            <div className="hidden md:flex items-center space-x-8">
              <a href="#about" className="text-gray-300 hover:text-brand-yellow transition-colors">About</a>
              <a href="#services" className="text-gray-300 hover:text-brand-yellow transition-colors">Services</a>
              <a href="#roadmap" className="text-gray-300 hover:text-brand-yellow transition-colors">Roadmap</a>
              <a href="#contact" className="px-4 py-2 rounded-md bg-brand-blue text-white hover:bg-blue-700 transition-colors">Contact</a>
            </div>
          </div>
        </div>
      </nav>

      <Hero />
      <About />
      <Services />
      <Roadmap />
      <Contact />
      
      {/* Footer */}
      <footer className="bg-black text-white py-8 border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row justify-between items-center">
          <div className="mb-4 md:mb-0">
            <span className="text-lg font-bold">Rahul Prajapati</span>
            <p className="text-gray-400 text-sm">AI Journalist & Data Storyteller</p>
          </div>
          <div className="text-sm text-gray-500">
             © {new Date().getFullYear()} All rights reserved.
          </div>
        </div>
      </footer>

      {/* AI Assistant */}
      <Chatbot />
    </div>
  );
};

export default App;