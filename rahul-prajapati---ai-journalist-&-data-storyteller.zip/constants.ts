import { Service, RoadmapStep, ExperienceItem } from './types';

export const PROFILE = {
  name: "Rahul Prajapati",
  title: "AI Journalist & Content Creator | Data Storyteller",
  tagline: "I help professionals grow using AI + Storytelling. Unconventional paths are my specialty.",
  contact: {
    email: "rahulprajapatifrelancer@gmail.com",
    linkedin: "www.linkedin.com/in/rahul-prajapati-4a951020a",
    phone: "8617656530"
  },
  about: `I spent 14 months working on India's biggest reality show (Bigg Boss) as a Camera Assistant, managing 14M live viewers. Then I switched to mining analytics, preventing lakhs in downtime. Now, I'm building a career in AI journalism and content creation. I prove that unconventional career paths aren't just valid—they're your competitive advantage.`,
  skills: ["AI Agents", "Generative AI", "Data Storytelling", "LinkedIn Growth", "Predictive Analytics"]
};

export const SERVICES: Service[] = [
  {
    id: "content-creation",
    title: "AI Content Creation & Ghostwriting",
    description: "High-impact LinkedIn posts, articles, and strategies using AI + Storytelling.",
    icon: "PenTool",
    packages: [
      { name: "Single Post", price: "$200 - $500" },
      { name: "Monthly Content Bundle (4 posts + strategy)", price: "$1,000 - $1,500" },
      { name: "Full LinkedIn Ghostwriting (20 posts/mo)", price: "$2,000 - $3,500" }
    ]
  },
  {
    id: "strategy",
    title: "Content Strategy & Optimization",
    description: "Build personal brands, optimize profiles, and create content calendars for coaches & creators.",
    icon: "TrendingUp",
    packages: [
      { name: "Profile Audit & Optimization", price: "$300 - $500" },
      { name: "1-Month Strategy", price: "$800" },
      { name: "3-Month Growth Program", price: "$2,500" }
    ]
  },
  {
    id: "data-storytelling",
    title: "Data Storytelling & Analytics",
    description: "Turn data/KPIs into compelling narratives, dashboards, and reports.",
    icon: "BarChart3",
    packages: [
      { name: "Dashboard Storytelling Session", price: "$400/hour" },
      { name: "Monthly Analytics Reports", price: "$1,500" },
      { name: "Quarterly Analytics Strategy", price: "$5,000" }
    ]
  },
  {
    id: "coaching",
    title: "Career Pivot & Branding Coaching",
    description: "Reframe unconventional career paths and monetize expertise.",
    icon: "Users",
    packages: [
      { name: "1:1 Career Pivot Session", price: "$100 - $200/hour" },
      { name: "3-Month Coaching Program", price: "$1,500" },
      { name: "Group Workshop", price: "$2,000 - $3,000" }
    ]
  },
  {
    id: "monetization",
    title: "Monetization Framework",
    description: "Build passive income through digital products and consulting.",
    icon: "DollarSign",
    packages: [
      { name: "Monetization Audit", price: "$300" },
      { name: "Done-For-You Setup", price: "$1,500" },
      { name: "6-Month Program", price: "$3,500" }
    ]
  }
];

export const ROADMAP: RoadmapStep[] = [
  {
    phase: "Phase 1",
    title: "Lead Generation",
    duration: "Week 1-2",
    items: [
      "Identify ideal clients (Coaches, founders).",
      "Cold outreach via LinkedIn & DMs.",
      "Value-first messaging: 'I help coaches grow 0-5K followers'."
    ]
  },
  {
    phase: "Phase 2",
    title: "Discovery & Proposal",
    duration: "Week 2-3",
    items: [
      "15-min Lead Qualification Call.",
      "30-min Detailed Discovery Session (Voice, Audience, Goals).",
      "Create tailored proposal with 3-tier pricing."
    ]
  },
  {
    phase: "Phase 3",
    title: "Onboarding",
    duration: "Week 3-4",
    items: [
      "Contract signing & 50% Upfront Payment.",
      "Onboarding Call: Collect stories & results.",
      "Create Brand Voice Document & Content Pillars."
    ]
  },
  {
    phase: "Phase 4",
    title: "Content Delivery",
    duration: "Week 4-12",
    items: [
      "Weekly Creation Cycle: Draft -> Approve -> Publish -> Engage.",
      "Monday: Create Post + Design.",
      "Friday: Engage with comments.",
      "Monthly Check-in & Performance Report."
    ]
  },
  {
    phase: "Phase 5",
    title: "Completion & Renewal",
    duration: "Week 12+",
    items: [
      "Final Presentation: 90-day results & ROI.",
      "Request Testimonials (LinkedIn Recommendations).",
      "Renewal: Extend, Refer, or Upsell to DFY."
    ]
  }
];

export const EXPERIENCE: ExperienceItem[] = [
  {
    company: "Narayani Sons India",
    role: "MIS Executive",
    duration: "March 2024 - Present",
    description: [
      "Prevented ₹15+ lakhs monthly losses through equipment analytics.",
      "Reduced equipment downtime by 60%.",
      "Built real-time KPI dashboards."
    ]
  },
  {
    company: "Bigg Boss (Endemol Shine)",
    role: "Camera Assistant",
    duration: "2022 - 2024",
    description: [
      "Worked on Bigg Boss Hindi S16, Kannada S10, Malayalam S05.",
      "Managed 12 cameras for live broadcasts with 14M+ viewers.",
      "High-pressure environment requiring precision and coordination."
    ]
  }
];

export const SYSTEM_PROMPT = `
You are the AI assistant for Rahul Prajapati's personal portfolio website.
Rahul is an "AI Journalist & Content Creator" and "Data Storyteller".
He has a unique background: He was a Camera Assistant for Bigg Boss (India's biggest reality show) and an MIS Executive in mining before pivoting to AI.

Here are his core services and pricing:
1. AI Content Creation: Single Post ($200-500), Monthly Bundle ($1000-1500), Full Ghostwriting ($2000-3500).
2. Content Strategy: Profile Audit ($300-500), 1-Month Strategy ($800), 3-Month Growth ($2500).
3. Data Storytelling: $400/hr consulting, $1500 monthly reports.
4. Career Pivot Coaching: $100-200/hr.
5. Monetization Setup: $1500 DFY setup.

His Process (The Roadmap):
- Weeks 1-2: Lead Gen.
- Weeks 2-3: Discovery & Proposal (50% upfront payment).
- Weeks 3-4: Onboarding (Voice doc, content pillars).
- Weeks 4-12: Delivery (Weekly posts, engagement, monthly reports).
- Week 12+: Renewal or Upsell.

His contact info: rahulprajapatifrelancer@gmail.com.
Tone: Professional, helpful, slightly informal but confident. Use the "Blue and Yellow" theme in your personality (Trustworthy but Energetic).

If asked about his background: Emphasize the "Unconventional Path" as a competitive advantage. He combines technical data skills with visual storytelling (camera work) and AI.

If asked to book: Suggest sending a DM on LinkedIn or emailing him directly.
`;
