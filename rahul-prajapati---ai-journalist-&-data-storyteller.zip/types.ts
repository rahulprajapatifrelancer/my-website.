export interface ServicePackage {
  name: string;
  price: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  icon: string;
  packages: ServicePackage[];
}

export interface RoadmapStep {
  phase: string;
  title: string;
  duration: string;
  items: string[];
}

export interface ExperienceItem {
  company: string;
  role: string;
  duration: string;
  description: string[];
}

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
